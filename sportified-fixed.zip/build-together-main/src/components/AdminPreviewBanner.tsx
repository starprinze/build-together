import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Shield, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Shown to super admins when they're viewing the public-facing site.
 * Fixed at the top so it's always visible. Only renders for super admins.
 */
export default function AdminPreviewBanner() {
  const { isSuperAdmin } = useAuth();
  if (!isSuperAdmin) return null;

  return (
    <div className="fixed top-0 inset-x-0 z-[9999] flex items-center justify-between gap-3 px-4 py-2 bg-primary text-primary-foreground shadow-court">
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Shield className="h-4 w-4 shrink-0" />
        <span className="uppercase tracking-wider text-xs font-bold">Admin Preview Mode</span>
        <span className="hidden sm:inline text-primary-foreground/70 font-normal text-xs">
          — You are viewing the public site as a super admin
        </span>
      </div>
      <Button
        asChild
        size="sm"
        variant="secondary"
        className="shrink-0 text-xs h-7 px-3 font-semibold"
      >
        <Link to="/super-admin">
          <ArrowLeft className="h-3.5 w-3.5 mr-1" />
          Return to Dashboard
        </Link>
      </Button>
    </div>
  );
}
