import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Trophy, Plus, Pencil, Trash2, Archive, ArchiveRestore, RefreshCw,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

type FixtureFormat = "single_elim" | "double_elim" | "round_robin" | "league";
type EventStatus = "upcoming" | "ongoing" | "completed" | "archived";
type TabFilter = "all" | "active" | "draft" | "completed" | "archived";

interface Event {
  id: string;
  name: string;
  sport: string;
  start_date: string;
  end_date: string;
  status: EventStatus;
  format: FixtureFormat;
  organization_id: string | null;
  updated_at?: string | null;
}

interface Org {
  id: string;
  name: string;
}

const FORMAT_LABELS: Record<FixtureFormat, string> = {
  single_elim: "Single elimination",
  double_elim: "Double elimination",
  round_robin: "Round robin",
  league: "League (home & away)",
};

const STATUS_BADGE: Record<EventStatus, string> = {
  upcoming: "bg-accent text-accent-foreground border-transparent",
  ongoing: "bg-success/15 text-success border-success/30",
  completed: "bg-muted text-muted-foreground border-transparent",
  archived: "bg-destructive/10 text-destructive border-destructive/20",
};

const TABS: { key: TabFilter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "draft", label: "Draft" },
  { key: "completed", label: "Completed" },
  { key: "archived", label: "Archived" },
];

const emptyEvent = {
  name: "", sport: "", start_date: "", end_date: "",
  status: "upcoming" as EventStatus, format: "single_elim" as FixtureFormat,
};

export default function AdminEvents() {
  const { isSuperAdmin, managedOrgId } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [tab, setTab] = useState<TabFilter>("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Event | null>(null);
  const [form, setForm] = useState(emptyEvent);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    let query = supabase
      .from("events")
      .select("*")
      .order("start_date", { ascending: false });

    if (!isSuperAdmin && managedOrgId) {
      query = query.eq("organization_id", managedOrgId);
    } else if (!isSuperAdmin && !managedOrgId) {
      setEvents([]);
      setLoading(false);
      return;
    }

    const { data } = await query;
    setEvents((data as Event[]) ?? []);

    if (isSuperAdmin) {
      const { data: orgData } = await supabase
        .from("organizations")
        .select("id,name")
        .order("name");
      setOrgs((orgData as Org[]) ?? []);
    }
    setLoading(false);
  };

  useEffect(() => { void load(); }, [isSuperAdmin, managedOrgId]);

  const filtered = events.filter((ev) => {
    if (tab === "all") return true;
    if (tab === "active") return ev.status === "upcoming" || ev.status === "ongoing";
    if (tab === "draft") return ev.status === "upcoming";
    return ev.status === tab;
  });

  const counts: Record<TabFilter, number> = {
    all: events.length,
    active: events.filter((e) => e.status === "upcoming" || e.status === "ongoing").length,
    draft: events.filter((e) => e.status === "upcoming").length,
    completed: events.filter((e) => e.status === "completed").length,
    archived: events.filter((e) => e.status === "archived").length,
  };

  const orgName = (id: string | null) =>
    id ? (orgs.find((o) => o.id === id)?.name ?? "—") : "—";

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editing) {
        const { error } = await supabase.from("events").update(form).eq("id", editing.id);
        if (error) throw error;
        toast.success("Event updated");
      } else {
        const payload = managedOrgId ? { ...form, organization_id: managedOrgId } : form;
        const { error } = await supabase.from("events").insert(payload);
        if (error) throw error;
        toast.success("Event created");
      }
      setOpen(false);
      setEditing(null);
      setForm(emptyEvent);
      load();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  /** Permanent delete — only super admin. Cascades via FK on_delete or triggers. */
  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Event permanently deleted"); load(); }
  };

  /** Toggle archive / restore */
  const handleArchive = async (ev: Event) => {
    const next: EventStatus = ev.status === "archived" ? "completed" : "archived";
    const { error } = await supabase.from("events").update({ status: next }).eq("id", ev.id);
    if (error) toast.error(error.message);
    else {
      toast.success(next === "archived" ? "Event archived" : "Event restored");
      load();
    }
  };

  const openCreate = () => { setEditing(null); setForm(emptyEvent); setOpen(true); };
  const openEdit = (ev: Event) => {
    setEditing(ev);
    setForm({
      name: ev.name, sport: ev.sport,
      start_date: ev.start_date, end_date: ev.end_date,
      status: ev.status, format: ev.format ?? "single_elim",
    });
    setOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold">Events</h1>
          <p className="text-sm text-muted-foreground">
            {isSuperAdmin ? "All events across the platform." : "Events for your organization."}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={cn("h-4 w-4 mr-1", loading && "animate-spin")} />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={openCreate} className="shadow-court">
                <Plus className="h-4 w-4 mr-1" /> New event
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editing ? "Edit event" : "Create event"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSave} className="space-y-4">
                <div>
                  <Label>Name</Label>
                  <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div>
                  <Label>Sport</Label>
                  <Input required value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Start date</Label>
                    <Input type="date" required value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
                  </div>
                  <div>
                    <Label>End date</Label>
                    <Input type="date" required value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
                  </div>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={(v: any) => setForm({ ...form, status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="upcoming">Upcoming</SelectItem>
                      <SelectItem value="ongoing">Ongoing</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Tournament format</Label>
                  <Select value={form.format} onValueChange={(v: FixtureFormat) => setForm({ ...form, format: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(Object.keys(FORMAT_LABELS) as FixtureFormat[]).map((k) => (
                        <SelectItem key={k} value={k}>{FORMAT_LABELS[k]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="submit" className="shadow-court">{editing ? "Save changes" : "Create"}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto border-b border-border pb-0 no-scrollbar">
        {TABS.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors",
              tab === key
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            )}
          >
            {label}
            <span className={cn(
              "inline-flex items-center justify-center rounded-full px-1.5 py-0.5 text-[10px] font-bold min-w-[18px]",
              tab === key ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            )}>
              {counts[key]}
            </span>
          </button>
        ))}
      </div>

      {/* Event list */}
      {loading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-20 rounded-xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12 text-center">
          <Trophy className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
          <p className="text-muted-foreground">
            {tab === "archived"
              ? "No archived events."
              : "No events in this category."}
          </p>
        </Card>
      ) : (
        <div className="grid gap-3">
          {filtered.map((ev) => (
            <Card key={ev.id} className={cn(
              "p-4 flex items-center justify-between gap-4 shadow-card",
              ev.status === "archived" && "opacity-75 border-dashed"
            )}>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <h3 className="font-display font-semibold truncate">{ev.name}</h3>
                  <span className={cn(
                    "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border",
                    STATUS_BADGE[ev.status]
                  )}>
                    {ev.status}
                  </span>
                  <Badge variant="secondary" className="text-xs">{FORMAT_LABELS[ev.format ?? "single_elim"]}</Badge>
                </div>
                <p className="text-sm text-muted-foreground truncate">
                  {ev.sport}
                  {isSuperAdmin && ev.organization_id && (
                    <> · <span className="text-muted-foreground/70">{orgName(ev.organization_id)}</span></>
                  )}
                  {" · "}
                  {new Date(ev.start_date).toLocaleDateString()} → {new Date(ev.end_date).toLocaleDateString()}
                </p>
                {ev.status === "archived" && ev.updated_at && (
                  <p className="text-xs text-destructive/70 mt-0.5">
                    Archived {new Date(ev.updated_at).toLocaleDateString()}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <Button asChild variant="ghost" size="sm">
                  <Link to={`/events/${ev.id}`}>View</Link>
                </Button>
                {ev.status !== "archived" && (
                  <Button variant="ghost" size="icon" onClick={() => openEdit(ev)} title="Edit">
                    <Pencil className="h-4 w-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleArchive(ev)}
                  title={ev.status === "archived" ? "Restore event" : "Archive event"}
                >
                  {ev.status === "archived" ? (
                    <ArchiveRestore className="h-4 w-4 text-success" />
                  ) : (
                    <Archive className="h-4 w-4" />
                  )}
                </Button>

                {/* Permanent delete — super admin only */}
                {isSuperAdmin && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" title="Delete permanently">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete "{ev.name}" permanently?</AlertDialogTitle>
                        <AlertDialogDescription asChild>
                          <div className="space-y-2 text-left">
                            <p>This will permanently remove:</p>
                            <ul className="list-disc pl-5 space-y-0.5 text-sm">
                              <li>Event & metadata</li>
                              <li>All matches & fixtures</li>
                              <li>Team registrations</li>
                              <li>Predictions & points</li>
                              <li>Leaderboard records</li>
                              <li>Gallery & media items</li>
                              <li>Standings data</li>
                            </ul>
                            <p className="font-semibold text-destructive">This action cannot be undone.</p>
                          </div>
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => handleDelete(ev.id)}
                        >
                          Delete permanently
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
