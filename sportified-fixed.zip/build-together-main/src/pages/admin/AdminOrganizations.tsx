import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Building2, Plus, Pencil, Trash2, Users, Trophy, RefreshCw, Calendar } from "lucide-react";

interface Org {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  created_at: string;
  owner_id: string | null;
  ownerEmail?: string | null;
  eventCount?: number;
  memberCount?: number;
}

const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);

export default function AdminOrganizations() {
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Org | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("organizations")
      .select("id,name,slug,description,created_at,owner_id")
      .order("created_at", { ascending: false });
    const list = (data as Org[]) ?? [];

    // Count events and members per org
    const [evRes, memRes] = await Promise.all([
      supabase.from("events").select("organization_id"),
      supabase.from("organization_members").select("organization_id"),
    ]);

    const evTally: Record<string, number> = {};
    (evRes.data ?? []).forEach((e: any) => {
      if (e.organization_id) evTally[e.organization_id] = (evTally[e.organization_id] ?? 0) + 1;
    });

    const memTally: Record<string, number> = {};
    (memRes.data ?? []).forEach((m: any) => {
      if (m.organization_id) memTally[m.organization_id] = (memTally[m.organization_id] ?? 0) + 1;
    });

    setOrgs(list.map((o) => ({
      ...o,
      eventCount: evTally[o.id] ?? 0,
      memberCount: memTally[o.id] ?? 0,
    })));
    setLoading(false);
  };

  useEffect(() => { void load(); }, []);

  const openCreate = () => { setEditing(null); setName(""); setDescription(""); setOpen(true); };
  const openEdit = (o: Org) => { setEditing(o); setName(o.name); setDescription(o.description ?? ""); setOpen(true); };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Enter a name");
    try {
      if (editing) {
        const { error } = await supabase
          .from("organizations")
          .update({ name: name.trim(), description: description.trim() || null })
          .eq("id", editing.id);
        if (error) throw error;
        toast.success("Organization updated");
      } else {
        const { data: { user } } = await supabase.auth.getUser();
        const slug = `${slugify(name) || "org"}-${Math.random().toString(36).slice(2, 6)}`;
        const { error } = await supabase
          .from("organizations")
          .insert({ name: name.trim(), description: description.trim() || null, slug, owner_id: user?.id });
        if (error) throw error;
        toast.success("Organization created");
      }
      setOpen(false);
      void load();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const remove = async (o: Org) => {
    const { error } = await supabase.from("organizations").delete().eq("id", o.id);
    if (error) toast.error(error.message);
    else { toast.success("Organization deleted"); void load(); }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold">Organizations</h1>
          <p className="text-sm text-muted-foreground">
            Govern every organization on the platform. Each org is fully isolated.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={openCreate} className="shadow-court">
                <Plus className="h-4 w-4 mr-1" /> New organization
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editing ? "Edit organization" : "Create organization"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={save} className="space-y-4">
                <div>
                  <Label>Name</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} required />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    placeholder="Optional description…"
                  />
                </div>
                <DialogFooter>
                  <Button type="submit" className="shadow-court">
                    {editing ? "Save changes" : "Create"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Hierarchy reminder */}
      <div className="rounded-lg border border-border bg-muted/30 px-4 py-3 text-xs text-muted-foreground flex items-center gap-2">
        <Building2 className="h-4 w-4 shrink-0 text-primary" />
        <span>
          <strong className="text-foreground">Platform hierarchy:</strong>{" "}
          Sportified → Organizations → Events → Matches → Predictions → Leaderboards.
          Organizer Admins can only access their assigned organization.
        </span>
      </div>

      {loading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-24 rounded-xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : orgs.length === 0 ? (
        <Card className="p-12 text-center">
          <Building2 className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
          <h3 className="font-display font-semibold text-lg mb-1">No organizations yet</h3>
          <p className="text-muted-foreground text-sm">Create the first organization to get started.</p>
        </Card>
      ) : (
        <div className="grid gap-3">
          {orgs.map((o) => (
            <Card key={o.id} className="p-5 shadow-card">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    <span className="grid place-items-center h-9 w-9 rounded-lg bg-accent shrink-0">
                      <Building2 className="h-4 w-4 text-primary" />
                    </span>
                    <h3 className="font-display font-semibold text-lg">{o.name}</h3>
                  </div>
                  {o.description && (
                    <p className="text-sm text-muted-foreground mb-2 max-w-prose">{o.description}</p>
                  )}
                  <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Trophy className="h-3.5 w-3.5" />
                      {o.eventCount} event{o.eventCount !== 1 ? "s" : ""}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5" />
                      {o.memberCount} member{o.memberCount !== 1 ? "s" : ""}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      Created {new Date(o.created_at).toLocaleDateString()}
                    </span>
                    <Badge variant="outline" className="text-[10px] font-mono">{o.slug}</Badge>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(o)} title="Edit">
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" title="Delete organization">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete "{o.name}"?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This organization's events will be detached. Members will lose access.
                          This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => remove(o)}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
