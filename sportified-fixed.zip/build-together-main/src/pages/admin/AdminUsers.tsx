import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  RefreshCw, UserCog, ShieldCheck, ShieldOff, UserX, UserCheck, Building2,
} from "lucide-react";
import { cn } from "@/lib/utils";

type PlatformRole = "super_admin" | "organizer_admin" | "staff" | "viewer";

interface UserRow {
  id: string;
  email: string | null;
  created_at: string;
  last_sign_in_at: string | null;
  is_admin: boolean;
  suspended?: boolean;
}

interface OrgMember {
  user_id: string;
  organization_id: string;
  role: string;
  org_name?: string;
}

interface Org {
  id: string;
  name: string;
}

const ROLE_LABELS: Record<PlatformRole, string> = {
  super_admin: "Super Admin",
  organizer_admin: "Organizer Admin",
  staff: "Staff",
  viewer: "Viewer",
};

const ROLE_BADGE: Record<PlatformRole, string> = {
  super_admin: "bg-primary text-primary-foreground",
  organizer_admin: "bg-success/15 text-success border border-success/30",
  staff: "bg-accent text-accent-foreground",
  viewer: "bg-muted text-muted-foreground",
};

function resolveRole(u: UserRow, members: OrgMember[]): PlatformRole {
  if (u.is_admin) return "super_admin";
  const m = members.find((m) => m.user_id === u.id);
  if (!m) return "viewer";
  if (m.role === "owner" || m.role === "organizer") return "organizer_admin";
  if (m.role === "staff") return "staff";
  return "viewer";
}

export default function AdminUsers() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [members, setMembers] = useState<OrgMember[]>([]);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");

  // Role assignment dialog
  const [assignTarget, setAssignTarget] = useState<UserRow | null>(null);
  const [assignRole, setAssignRole] = useState<PlatformRole>("viewer");
  const [assignOrg, setAssignOrg] = useState<string>("");

  const load = async () => {
    setLoading(true);
    try {
      const [usersRes, membersRes, orgsRes] = await Promise.all([
        supabase.functions.invoke("admin-users", { body: { action: "list", page: 1, perPage: 200 } }),
        supabase.from("organization_members").select("user_id,organization_id,role"),
        supabase.from("organizations").select("id,name").order("name"),
      ]);

      if (usersRes.error) throw usersRes.error;
      if ((usersRes.data as any)?.error) throw new Error((usersRes.data as any).error);

      const rawUsers: UserRow[] = (usersRes.data as any).users ?? [];
      setUsers(rawUsers);

      const rawMembers: OrgMember[] = (membersRes.data as OrgMember[]) ?? [];
      const rawOrgs: Org[] = (orgsRes.data as Org[]) ?? [];

      // Annotate member rows with org names
      const annotated = rawMembers.map((m) => ({
        ...m,
        org_name: rawOrgs.find((o) => o.id === m.organization_id)?.name,
      }));
      setMembers(annotated);
      setOrgs(rawOrgs);
    } catch (e: any) {
      toast.error(e.message ?? "Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const callRole = async (action: "grant" | "revoke", email: string) => {
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("admin-users", {
        body: { action, email },
      });
      if (error) throw error;
      if ((data as any)?.error) throw new Error((data as any).error);
      toast.success(action === "grant" ? "Super admin granted" : "Super admin revoked");
      await load();
    } catch (e: any) {
      toast.error(e.message ?? "Action failed");
    } finally {
      setBusy(false);
    }
  };

  const openAssign = (u: UserRow) => {
    const current = resolveRole(u, members);
    const m = members.find((m) => m.user_id === u.id);
    setAssignTarget(u);
    setAssignRole(current === "super_admin" ? "organizer_admin" : current);
    setAssignOrg(m?.organization_id ?? (orgs[0]?.id ?? ""));
  };

  const saveAssignment = async () => {
    if (!assignTarget) return;
    setBusy(true);
    try {
      // Handle super admin grant/revoke separately
      if (assignRole === "super_admin") {
        await callRole("grant", assignTarget.email ?? "");
        setAssignTarget(null);
        return;
      }
      if (assignTarget.is_admin) {
        // revoke super admin first
        await callRole("revoke", assignTarget.email ?? "");
      }

      const uid = assignTarget.id;

      // Remove existing membership
      await supabase.from("organization_members").delete().eq("user_id", uid);

      if (assignRole !== "viewer" && assignOrg) {
        const dbRole = assignRole === "organizer_admin" ? "organizer" : "staff";
        const { error } = await supabase.from("organization_members").upsert({
          user_id: uid,
          organization_id: assignOrg,
          role: dbRole,
        });
        if (error) throw error;
      }

      toast.success("Role updated successfully");
      setAssignTarget(null);
      await load();
    } catch (e: any) {
      toast.error(e.message ?? "Failed to update role");
    } finally {
      setBusy(false);
    }
  };

  const removeRole = async (u: UserRow) => {
    setBusy(true);
    try {
      await supabase.from("organization_members").delete().eq("user_id", u.id);
      if (u.is_admin && u.email) {
        await callRole("revoke", u.email);
      }
      toast.success("Role removed");
      await load();
    } catch (e: any) {
      toast.error(e.message ?? "Failed");
    } finally {
      setBusy(false);
    }
  };

  const filtered = users.filter((u) =>
    !search || (u.email ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const memberOf = (uid: string) => members.find((m) => m.user_id === uid);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold">User Management</h1>
          <p className="text-sm text-muted-foreground">
            Assign roles, manage organizations, and control platform access.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={cn("h-4 w-4 mr-2", loading && "animate-spin")} />
          Refresh
        </Button>
      </div>

      {/* Search */}
      <div className="flex items-center gap-3">
        <Input
          placeholder="Search by email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
        <span className="text-sm text-muted-foreground">{filtered.length} users</span>
      </div>

      {/* Table */}
      <Card className="p-0 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Organization</TableHead>
              <TableHead>Last sign-in</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-12">
                  Loading users…
                </TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-12">
                  No users found.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((u) => {
                const role = resolveRole(u, members);
                const m = memberOf(u.id);
                return (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.email ?? "—"}</TableCell>
                    <TableCell>
                      <span className={cn(
                        "inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-full",
                        ROLE_BADGE[role]
                      )}>
                        {role === "super_admin" && <ShieldCheck className="h-3 w-3" />}
                        {ROLE_LABELS[role]}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {m?.org_name ? (
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3.5 w-3.5" />
                          {m.org_name}
                        </span>
                      ) : "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {u.last_sign_in_at
                        ? new Date(u.last_sign_in_at).toLocaleDateString()
                        : "Never"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {/* Assign role */}
                        <Button
                          variant="ghost"
                          size="sm"
                          disabled={busy}
                          onClick={() => openAssign(u)}
                          title="Assign role"
                        >
                          <UserCog className="h-4 w-4 mr-1" />
                          Assign role
                        </Button>

                        {/* Remove role (non-super-admin) */}
                        {role !== "super_admin" && role !== "viewer" && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="sm" disabled={busy}>
                                <ShieldOff className="h-4 w-4 mr-1" />
                                Remove role
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Remove role from {u.email}?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This user will become a viewer with no management access.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => removeRole(u)}>
                                  Remove role
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}

                        {/* Revoke super admin */}
                        {role === "super_admin" && u.email && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="sm" disabled={busy}>
                                <ShieldOff className="h-4 w-4 mr-1 text-destructive" />
                                Revoke admin
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Revoke super admin from {u.email}?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  They will lose all platform-level access. This cannot be undone without re-granting.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-destructive text-destructive-foreground"
                                  onClick={() => u.email && callRole("revoke", u.email)}
                                >
                                  Revoke
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Role assignment dialog */}
      <Dialog open={!!assignTarget} onOpenChange={(o) => !o && setAssignTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign role</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="text-sm text-muted-foreground">
              User: <span className="font-medium text-foreground">{assignTarget?.email}</span>
            </div>

            <div>
              <Label>Role</Label>
              <Select
                value={assignRole}
                onValueChange={(v) => setAssignRole(v as PlatformRole)}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="viewer">Viewer — can browse, predict, follow matches</SelectItem>
                  <SelectItem value="staff">Staff — update scores, manage fixtures, upload media</SelectItem>
                  <SelectItem value="organizer_admin">Organizer Admin — manage assigned org events & teams</SelectItem>
                  <SelectItem value="super_admin">Super Admin — full platform control</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(assignRole === "organizer_admin" || assignRole === "staff") && (
              <div>
                <Label>Organization</Label>
                <Select value={assignOrg} onValueChange={setAssignOrg}>
                  <SelectTrigger><SelectValue placeholder="Select organization…" /></SelectTrigger>
                  <SelectContent>
                    {orgs.map((o) => (
                      <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  This user will only have access to this organization's events.
                </p>
              </div>
            )}

            {assignRole === "super_admin" && (
              <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                Super Admin grants full platform access. Use with caution.
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignTarget(null)}>Cancel</Button>
            <Button
              className="shadow-court"
              onClick={saveAssignment}
              disabled={busy || ((assignRole === "organizer_admin" || assignRole === "staff") && !assignOrg)}
            >
              {busy ? "Saving…" : "Save assignment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
