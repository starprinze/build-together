import { Link } from "react-router-dom";
import { Shield, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

/**
 * Fixed banner shown to super admins when browsing public pages.
 * Rendered inside Layout so it appears on every public route.
 */
export default function AdminPreviewBanner() {
  const { isSuperAdmin } = useAuth();
  if (!isSuperAdmin) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:bottom-auto md:top-0 md:z-[60] pointer-events-none">
      <div className="pointer-events-auto flex items-center justify-between gap-3 bg-primary px-4 py-2 text-primary-foreground shadow-court md:rounded-none">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Shield className="h-4 w-4 shrink-0" />
          <span className="uppercase tracking-widest text-xs font-bold">Admin Preview Mode</span>
        </div>
        <Button
          asChild
          size="sm"
          variant="secondary"
          className="shrink-0 text-xs h-7 px-3"
        >
          <Link to="/super-admin">
            <ArrowLeft className="h-3.5 w-3.5 mr-1" />
            Return to Dashboard
          </Link>
        </Button>
      </div>
    </div>
  );
}
