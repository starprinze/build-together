import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Trophy, Plus, Pencil, Trash2, Archive, ArchiveRestore, RotateCcw,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type FixtureFormat = "single_elim" | "double_elim" | "round_robin" | "league";
type EventStatus = "upcoming" | "ongoing" | "completed" | "archived";
type TabKey = "all" | "active" | "draft" | "completed" | "archived";

interface Event {
  id: string;
  name: string;
  sport: string;
  start_date: string;
  end_date: string;
  status: EventStatus;
  format: FixtureFormat;
  organization_id: string | null;
  created_at: string;
  updated_at?: string;
}

interface OrgName { id: string; name: string; }

const FORMAT_LABELS: Record<FixtureFormat, string> = {
  single_elim: "Single elimination",
  double_elim: "Double elimination",
  round_robin: "Round robin",
  league: "League (home & away)",
};

const STATUS_BADGE: Record<EventStatus, string> = {
  upcoming: "bg-accent text-accent-foreground border-transparent",
  ongoing: "bg-success/15 text-success border-success/30",
  completed: "bg-muted text-muted-foreground border-transparent",
  archived: "bg-destructive/15 text-destructive border-destructive/30",
};

const TABS: { key: TabKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "draft", label: "Draft" },
  { key: "completed", label: "Completed" },
  { key: "archived", label: "Archived" },
];

const emptyForm = {
  name: "", sport: "", start_date: "", end_date: "",
  status: "upcoming" as EventStatus, format: "single_elim" as FixtureFormat,
};

function filterByTab(events: Event[], tab: TabKey): Event[] {
  switch (tab) {
    case "active": return events.filter((e) => e.status === "ongoing" || e.status === "upcoming");
    case "draft": return events.filter((e) => e.status === "upcoming");
    case "completed": return events.filter((e) => e.status === "completed");
    case "archived": return events.filter((e) => e.status === "archived");
    default: return events;
  }
}

export default function AdminEvents() {
  const { isSuperAdmin, managedOrgId } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [orgs, setOrgs] = useState<OrgName[]>([]);
  const [tab, setTab] = useState<TabKey>("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Event | null>(null);
  const [form, setForm] = useState(emptyForm);

  const load = async () => {
    let query = supabase
      .from("events")
      .select("*")
      .order("start_date", { ascending: false });
    if (!isSuperAdmin && managedOrgId) {
      query = query.eq("organization_id", managedOrgId);
    } else if (!isSuperAdmin && !managedOrgId) {
      setEvents([]);
      return;
    }
    const { data } = await query;
    setEvents((data as Event[]) ?? []);
  };

  useEffect(() => {
    load();
    if (isSuperAdmin) {
      supabase.from("organizations").select("id,name").then(({ data }) => {
        setOrgs((data as OrgName[]) ?? []);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuperAdmin, managedOrgId]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editing) {
        const { error } = await supabase.from("events").update(form).eq("id", editing.id);
        if (error) throw error;
        toast.success("Event updated");
      } else {
        const payload = managedOrgId ? { ...form, organization_id: managedOrgId } : form;
        const { error } = await supabase.from("events").insert(payload);
        if (error) throw error;
        toast.success("Event created");
      }
      setOpen(false);
      setEditing(null);
      setForm(emptyForm);
      load();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handlePermanentDelete = async (id: string) => {
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Event permanently deleted");
      load();
    }
  };

  const handleArchive = async (ev: Event) => {
    const { error } = await supabase.from("events").update({ status: "archived" }).eq("id", ev.id);
    if (error) toast.error(error.message);
    else { toast.success("Event archived"); load(); }
  };

  const handleRestore = async (ev: Event) => {
    // Restore to "completed" if dates are past, otherwise "upcoming"
    const restoredStatus: EventStatus = new Date(ev.end_date) < new Date() ? "completed" : "upcoming";
    const { error } = await supabase.from("events").update({ status: restoredStatus }).eq("id", ev.id);
    if (error) toast.error(error.message);
    else { toast.success("Event restored"); load(); }
  };

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (ev: Event) => {
    setEditing(ev);
    setForm({
      name: ev.name, sport: ev.sport,
      start_date: ev.start_date, end_date: ev.end_date,
      status: ev.status, format: ev.format ?? "single_elim",
    });
    setOpen(true);
  };

  const filtered = filterByTab(events, tab);
  const tabCounts = TABS.reduce((acc, t) => {
    acc[t.key] = filterByTab(events, t.key).length;
    return acc;
  }, {} as Record<TabKey, number>);

  const orgName = (id: string | null) =>
    orgs.find((o) => o.id === id)?.name ?? "—";

  return (
    <div>
      <div className="flex items-center justify-between mb-5 gap-3 flex-wrap">
        <h1 className="text-2xl font-display font-bold">Events</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreate} className="shadow-court">
              <Plus className="h-4 w-4 mr-1" /> New event
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editing ? "Edit event" : "Create event"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <Label>Sport</Label>
                <Input required value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Start date</Label>
                  <Input type="date" required value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
                </div>
                <div>
                  <Label>End date</Label>
                  <Input type="date" required value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
                </div>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v: any) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upcoming">Upcoming</SelectItem>
                    <SelectItem value="ongoing">Ongoing</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tournament format</Label>
                <Select value={form.format} onValueChange={(v: FixtureFormat) => setForm({ ...form, format: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(Object.keys(FORMAT_LABELS) as FixtureFormat[]).map((k) => (
                      <SelectItem key={k} value={k}>{FORMAT_LABELS[k]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="submit" className="shadow-court">{editing ? "Save changes" : "Create"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto mb-5 border-b border-border pb-1 no-scrollbar">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 whitespace-nowrap px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
              tab === t.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            }`}
          >
            {t.label}
            <span className={`text-xs rounded-full px-1.5 ${
              tab === t.key ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}>
              {tabCounts[t.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Archived tab — special layout */}
      {tab === "archived" ? (
        <ArchivedEventsPanel
          events={filtered}
          isSuperAdmin={isSuperAdmin}
          orgName={orgName}
          onRestore={handleRestore}
          onPermanentDelete={handlePermanentDelete}
        />
      ) : filtered.length === 0 ? (
        <Card className="p-12 text-center">
          <Trophy className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
          <p className="text-muted-foreground text-sm">No events in this category.</p>
        </Card>
      ) : (
        <div className="grid gap-3">
          {filtered.map((ev) => (
            <Card key={ev.id} className="p-4 flex items-center justify-between gap-4 shadow-card">
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                  <h3 className="font-display font-semibold truncate">{ev.name}</h3>
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${STATUS_BADGE[ev.status]}`}>
                    {ev.status}
                  </span>
                  <Badge variant="secondary" className="text-xs">{FORMAT_LABELS[ev.format ?? "single_elim"]}</Badge>
                </div>
                <p className="text-sm text-muted-foreground truncate">
                  {ev.sport}
                  {isSuperAdmin && ev.organization_id && ` · ${orgName(ev.organization_id)}`}
                  {" · "}
                  {new Date(ev.start_date).toLocaleDateString()} → {new Date(ev.end_date).toLocaleDateString()}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button asChild variant="ghost" size="sm"><Link to={`/events/${ev.id}`}>View</Link></Button>
                <Button variant="ghost" size="icon" onClick={() => openEdit(ev)} title="Edit">
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleArchive(ev)} title="Archive">
                  <Archive className="h-4 w-4" />
                </Button>
                {isSuperAdmin && (
                  <PermanentDeleteDialog ev={ev} onConfirm={() => handlePermanentDelete(ev.id)} />
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Archived Events Panel ── */
function ArchivedEventsPanel({
  events, isSuperAdmin, orgName, onRestore, onPermanentDelete,
}: {
  events: Event[];
  isSuperAdmin: boolean;
  orgName: (id: string | null) => string;
  onRestore: (ev: Event) => void;
  onPermanentDelete: (id: string) => void;
}) {
  if (events.length === 0) {
    return (
      <Card className="p-12 text-center">
        <Archive className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
        <p className="text-muted-foreground text-sm">No archived events.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        Archived events are hidden from the public site. Restore them to make them visible again, or permanently delete to free up space.
      </p>
      <div className="grid gap-3">
        {events.map((ev) => (
          <Card key={ev.id} className="p-4 shadow-card border-destructive/20">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div className="min-w-0 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-display font-semibold">{ev.name}</h3>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border bg-destructive/15 text-destructive border-destructive/30">
                    Archived
                  </span>
                </div>
                <div className="text-sm text-muted-foreground grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-0.5">
                  <span><span className="font-medium text-foreground">Sport:</span> {ev.sport}</span>
                  {isSuperAdmin && (
                    <span><span className="font-medium text-foreground">Org:</span> {orgName(ev.organization_id)}</span>
                  )}
                  <span>
                    <span className="font-medium text-foreground">Event dates:</span>{" "}
                    {new Date(ev.start_date).toLocaleDateString()} → {new Date(ev.end_date).toLocaleDateString()}
                  </span>
                  <span>
                    <span className="font-medium text-foreground">Format:</span>{" "}
                    {FORMAT_LABELS[ev.format ?? "single_elim"]}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onRestore(ev)}
                  className="gap-1.5"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Restore
                </Button>
                {isSuperAdmin && (
                  <PermanentDeleteDialog ev={ev} onConfirm={() => onPermanentDelete(ev.id)} />
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ── Permanent Delete Confirmation ── */
function PermanentDeleteDialog({ ev, onConfirm }: { ev: Event; onConfirm: () => void }) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="ghost" size="icon" title="Delete permanently">
          <Trash2 className="h-4 w-4 text-destructive" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete "{ev.name}" permanently?</AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-3 text-left">
              <p>This will permanently remove:</p>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                <li>Event record &amp; metadata</li>
                <li>All matches &amp; scores</li>
                <li>All teams</li>
                <li>All predictions</li>
                <li>Leaderboard data</li>
                <li>Gallery items &amp; media</li>
                <li>Standings</li>
              </ul>
              <p className="font-semibold text-destructive">This action cannot be undone.</p>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            onClick={onConfirm}
          >
            Delete permanently
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
