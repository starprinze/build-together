import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Building2, Plus, Pencil, Trash2, Users, Trophy, Archive, Eye } from "lucide-react";
import { Link } from "react-router-dom";

interface Org {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  owner_id: string | null;
  created_at: string;
  ownerEmail?: string | null;
  eventCount: number;
  memberCount: number;
  isArchived?: boolean;
}

const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);

export default function AdminOrganizations() {
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Org | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const { data: orgData } = await supabase
        .from("organizations")
        .select("id,name,slug,description,owner_id,created_at")
        .order("created_at", { ascending: false });

      const list = (orgData as Org[]) ?? [];

      // Event counts
      const { data: events } = await supabase.from("events").select("organization_id");
      const eventTally: Record<string, number> = {};
      (events ?? []).forEach((e: any) => {
        if (e.organization_id) eventTally[e.organization_id] = (eventTally[e.organization_id] ?? 0) + 1;
      });

      // Member counts
      const { data: members } = await supabase
        .from("organization_members")
        .select("organization_id");
      const memberTally: Record<string, number> = {};
      (members ?? []).forEach((m: any) => {
        if (m.organization_id) memberTally[m.organization_id] = (memberTally[m.organization_id] ?? 0) + 1;
      });

      // Owner emails via edge function
      const ownerIds = [...new Set(list.map((o) => o.owner_id).filter(Boolean))] as string[];
      const ownerEmailMap: Record<string, string> = {};
      if (ownerIds.length) {
        const { data: fnData } = await supabase.functions.invoke("admin-users", {
          body: { action: "list", page: 1, perPage: 500 },
        });
        const authUsers: { id: string; email: string | null }[] = (fnData as any)?.users ?? [];
        authUsers.forEach((u) => { if (u.email) ownerEmailMap[u.id] = u.email; });
      }

      setOrgs(list.map((o) => ({
        ...o,
        eventCount: eventTally[o.id] ?? 0,
        memberCount: memberTally[o.id] ?? 0,
        ownerEmail: o.owner_id ? ownerEmailMap[o.owner_id] ?? null : null,
      })));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const openCreate = () => {
    setEditing(null);
    setName("");
    setDescription("");
    setOpen(true);
  };

  const openEdit = (o: Org) => {
    setEditing(o);
    setName(o.name);
    setDescription(o.description ?? "");
    setOpen(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Enter a name");
    try {
      if (editing) {
        const { error } = await supabase
          .from("organizations")
          .update({ name: name.trim(), description: description.trim() || null })
          .eq("id", editing.id);
        if (error) throw error;
        toast.success("Organization updated");
      } else {
        const { data: { user } } = await supabase.auth.getUser();
        const slug = `${slugify(name) || "org"}-${Math.random().toString(36).slice(2, 6)}`;
        const { error } = await supabase
          .from("organizations")
          .insert({ name: name.trim(), description: description.trim() || null, slug, owner_id: user?.id });
        if (error) throw error;
        toast.success("Organization created");
      }
      setOpen(false);
      load();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const archiveOrg = async (o: Org) => {
    // Archive all events under this org
    const { error } = await supabase
      .from("events")
      .update({ status: "archived" })
      .eq("organization_id", o.id)
      .neq("status", "archived");
    if (error) toast.error(error.message);
    else toast.success(`Archived all events for "${o.name}"`);
    load();
  };

  const remove = async (o: Org) => {
    const { error } = await supabase.from("organizations").delete().eq("id", o.id);
    if (error) toast.error(error.message);
    else { toast.success("Organization deleted"); load(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold">Organizations</h1>
          <p className="text-sm text-muted-foreground">
            Govern every organization on the Sportified platform.
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreate} className="shadow-court">
              <Plus className="h-4 w-4 mr-1" /> New organization
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editing ? "Edit organization" : "Create organization"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={save} className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
              </div>
              <DialogFooter>
                <Button type="submit" className="shadow-court">{editing ? "Save changes" : "Create"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Platform hierarchy note */}
      <Card className="p-4 bg-muted/40 border-dashed">
        <p className="text-xs text-muted-foreground font-mono">
          Sportified → Organizations → Events → Matches → Predictions → Leaderboards
        </p>
      </Card>

      {loading ? (
        <Card className="p-12 text-center text-muted-foreground">Loading…</Card>
      ) : orgs.length === 0 ? (
        <Card className="p-12 text-center">
          <Building2 className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
          <p className="text-muted-foreground">No organizations yet.</p>
        </Card>
      ) : (
        <div className="grid gap-4">
          {orgs.map((o) => (
            <Card key={o.id} className="p-5 shadow-card">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="min-w-0 space-y-2">
                  {/* Name + badges */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="grid place-items-center h-9 w-9 rounded-lg bg-gradient-court text-primary-foreground shrink-0">
                      <Building2 className="h-4 w-4" />
                    </div>
                    <h3 className="font-display font-bold text-lg">{o.name}</h3>
                  </div>

                  {/* Description */}
                  {o.description && (
                    <p className="text-sm text-muted-foreground max-w-prose">{o.description}</p>
                  )}

                  {/* Meta row */}
                  <div className="flex flex-wrap items-center gap-3 text-sm">
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Trophy className="h-3.5 w-3.5" />
                      {o.eventCount} event{o.eventCount !== 1 ? "s" : ""}
                    </span>
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Users className="h-3.5 w-3.5" />
                      {o.memberCount} member{o.memberCount !== 1 ? "s" : ""}
                    </span>
                    {o.ownerEmail && (
                      <span className="text-muted-foreground">
                        <span className="font-medium text-foreground">Owner:</span> {o.ownerEmail}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0 flex-wrap">
                  <Button asChild variant="ghost" size="sm">
                    <Link to={`/super-admin/events?org=${o.id}`}>
                      <Eye className="h-4 w-4 mr-1" /> View
                    </Link>
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => openEdit(o)} title="Edit">
                    <Pencil className="h-4 w-4" />
                  </Button>

                  {/* Archive org events */}
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" title="Archive all events">
                        <Archive className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Archive all events for "{o.name}"?</AlertDialogTitle>
                        <AlertDialogDescription>
                          All active events under this organization will be archived and hidden from the public site.
                          The organization itself will remain intact.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => archiveOrg(o)}>Archive events</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>

                  {/* Delete org */}
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" title="Delete organization">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete "{o.name}"?</AlertDialogTitle>
                        <AlertDialogDescription asChild>
                          <div className="space-y-2 text-left">
                            <p>Deleting this organization will:</p>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Remove the organization record</li>
                              <li>Detach its {o.eventCount} event(s) — they will still exist but be unaffiliated</li>
                              <li>Remove all member associations</li>
                            </ul>
                            <p className="font-semibold text-destructive">This cannot be undone.</p>
                          </div>
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => remove(o)}
                        >
                          Delete organization
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
