import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  RefreshCw, ShieldCheck, ShieldOff, UserX, UserCheck, Building2, Search,
} from "lucide-react";

type PlatformRole = "super_admin" | "organizer_admin" | "staff" | "viewer";
type UserStatus = "active" | "suspended";

interface ManagedUser {
  id: string;
  email: string | null;
  full_name: string | null;
  created_at: string;
  last_sign_in_at: string | null;
  platform_role: PlatformRole;
  org_id: string | null;
  org_name: string | null;
  status: UserStatus;
}

interface Org { id: string; name: string; }

const ROLE_BADGE: Record<PlatformRole, string> = {
  super_admin: "bg-primary text-primary-foreground",
  organizer_admin: "bg-success/20 text-success",
  staff: "bg-accent text-accent-foreground",
  viewer: "bg-muted text-muted-foreground",
};

const ROLE_LABELS: Record<PlatformRole, string> = {
  super_admin: "Super Admin",
  organizer_admin: "Organizer Admin",
  staff: "Staff",
  viewer: "Viewer",
};

export default function AdminUsers() {
  const { user: selfUser } = useAuth();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editTarget, setEditTarget] = useState<ManagedUser | null>(null);
  const [editRole, setEditRole] = useState<PlatformRole>("viewer");
  const [editOrg, setEditOrg] = useState<string>("none");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      // Load all profiles
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, created_at");

      // Load admin roles
      const { data: adminRoles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .eq("role", "admin");

      // Load org memberships
      const { data: memberships } = await supabase
        .from("organization_members")
        .select("user_id, role, organization_id");

      // Load org ownerships
      const { data: ownedOrgs } = await supabase
        .from("organizations")
        .select("id, name, owner_id");

      // Load orgs for dropdown
      const orgList = (ownedOrgs as Org[] ?? []);
      setOrgs(orgList);

      const adminSet = new Set((adminRoles ?? []).map((r: any) => r.user_id));
      const memberMap = new Map((memberships ?? []).map((m: any) => [m.user_id, m]));
      const ownerMap = new Map((ownedOrgs ?? []).map((o: any) => [o.owner_id, o]));
      const orgNameMap = new Map((ownedOrgs ?? []).map((o: any) => [o.id, o.name]));

      // Use admin-users edge function to get emails
      const { data: fnData } = await supabase.functions.invoke("admin-users", {
        body: { action: "list", page: 1, perPage: 500 },
      });
      const authUsers: { id: string; email: string | null; last_sign_in_at: string | null }[] =
        (fnData as any)?.users ?? [];
      const emailMap = new Map(authUsers.map((u) => [u.id, u]));

      const list: ManagedUser[] = (profiles as any[] ?? []).map((p) => {
        const auth = emailMap.get(p.id);
        const isAdmin = adminSet.has(p.id);
        const membership = memberMap.get(p.id);
        const ownedOrg = ownerMap.get(p.id);

        let platform_role: PlatformRole = "viewer";
        let org_id: string | null = null;
        let org_name: string | null = null;

        if (isAdmin) {
          platform_role = "super_admin";
        } else if (ownedOrg) {
          platform_role = "organizer_admin";
          org_id = ownedOrg.id;
          org_name = ownedOrg.name;
        } else if (membership) {
          org_id = membership.organization_id;
          org_name = orgNameMap.get(membership.organization_id) ?? null;
          if (membership.role === "organizer") platform_role = "organizer_admin";
          else if (membership.role === "staff") platform_role = "staff";
          else platform_role = "viewer";
        }

        return {
          id: p.id,
          email: auth?.email ?? null,
          full_name: p.full_name ?? null,
          created_at: p.created_at,
          last_sign_in_at: auth?.last_sign_in_at ?? null,
          platform_role,
          org_id,
          org_name,
          status: "active",
        };
      });

      setUsers(list);
    } catch (e: any) {
      toast.error(e.message ?? "Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const openEdit = (u: ManagedUser) => {
    setEditTarget(u);
    setEditRole(u.platform_role);
    setEditOrg(u.org_id ?? "none");
  };

  const saveRoleAssignment = async () => {
    if (!editTarget) return;
    setBusy(true);
    try {
      const uid = editTarget.id;
      const email = editTarget.email;

      // Clear existing admin role
      await supabase.from("user_roles").delete().eq("user_id", uid).eq("role", "admin");
      // Clear existing org memberships
      await supabase.from("organization_members").delete().eq("user_id", uid);
      // Clear org ownership (only if they were the owner and we're demoting)
      if (editTarget.platform_role === "organizer_admin" && editTarget.org_id) {
        const { data: currentOrg } = await supabase
          .from("organizations")
          .select("owner_id")
          .eq("id", editTarget.org_id)
          .maybeSingle();
        if ((currentOrg as any)?.owner_id === uid) {
          await supabase.from("organizations").update({ owner_id: null }).eq("id", editTarget.org_id);
        }
      }

      // Apply new role
      if (editRole === "super_admin") {
        if (!email) throw new Error("Cannot grant super admin to user without email");
        const { data, error } = await supabase.functions.invoke("admin-users", {
          body: { action: "grant", email },
        });
        if (error || (data as any)?.error) throw new Error((data as any)?.error ?? error?.message);
      } else if ((editRole === "organizer_admin" || editRole === "staff") && editOrg !== "none") {
        const orgRole = editRole === "organizer_admin" ? "organizer" : "staff";
        await supabase.from("organization_members").insert({
          user_id: uid,
          organization_id: editOrg,
          role: orgRole,
        });
      }

      toast.success("Role updated");
      setEditTarget(null);
      await load();
    } catch (e: any) {
      toast.error(e.message ?? "Failed to update role");
    } finally {
      setBusy(false);
    }
  };

  const removeRole = async (u: ManagedUser) => {
    setBusy(true);
    try {
      await supabase.from("user_roles").delete().eq("user_id", u.id).eq("role", "admin");
      await supabase.from("organization_members").delete().eq("user_id", u.id);
      toast.success("Role removed — user is now Viewer");
      await load();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  };

  const filtered = users.filter((u) => {
    const q = search.toLowerCase();
    return (
      !q ||
      u.email?.toLowerCase().includes(q) ||
      u.full_name?.toLowerCase().includes(q) ||
      u.org_name?.toLowerCase().includes(q)
    );
  });

  const needsOrg = editRole === "organizer_admin" || editRole === "staff";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold">User Management</h1>
          <p className="text-sm text-muted-foreground">
            Assign roles, manage organizations, and control user access.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Search by name, email, org…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Role legend */}
      <div className="flex flex-wrap gap-2 text-xs">
        {(Object.entries(ROLE_LABELS) as [PlatformRole, string][]).map(([r, l]) => (
          <span key={r} className={`px-2 py-0.5 rounded-full font-medium ${ROLE_BADGE[r]}`}>
            {l}
          </span>
        ))}
      </div>

      <Card className="p-0 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Role</TableHead>
              <TableHead className="hidden md:table-cell">Organization</TableHead>
              <TableHead className="hidden lg:table-cell">Last sign-in</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-10">
                  Loading users…
                </TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-10">
                  {search ? "No users match your search." : "No users yet."}
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((u) => {
                const isSelf = u.id === selfUser?.id;
                return (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="font-medium text-sm">{u.full_name ?? "—"}</div>
                      <div className="text-xs text-muted-foreground">{u.email ?? "—"}</div>
                    </TableCell>
                    <TableCell>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${ROLE_BADGE[u.platform_role]}`}>
                        {ROLE_LABELS[u.platform_role]}
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {u.org_name ? (
                        <span className="flex items-center gap-1 text-sm">
                          <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
                          {u.org_name}
                        </span>
                      ) : (
                        <span className="text-muted-foreground text-sm">—</span>
                      )}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground text-sm">
                      {u.last_sign_in_at
                        ? new Date(u.last_sign_in_at).toLocaleDateString()
                        : "Never"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {!isSelf && u.platform_role !== "super_admin" && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEdit(u)}
                              className="gap-1.5"
                            >
                              <ShieldCheck className="h-3.5 w-3.5" />
                              Assign role
                            </Button>
                            {u.platform_role !== "viewer" && (
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon" title="Remove role">
                                    <ShieldOff className="h-4 w-4 text-muted-foreground" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Remove role from {u.full_name ?? u.email}?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      This user will become a Viewer with no management access.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => removeRole(u)}>Remove role</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            )}
                          </>
                        )}
                        {isSelf && (
                          <Badge variant="secondary" className="text-xs">You</Badge>
                        )}
                        {u.platform_role === "super_admin" && !isSelf && (
                          <Badge className="bg-primary text-primary-foreground text-xs">Protected</Badge>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Edit Role Dialog */}
      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Role</DialogTitle>
          </DialogHeader>
          {editTarget && (
            <div className="space-y-4">
              <div className="rounded-lg bg-muted/50 p-3 text-sm space-y-1">
                <div className="font-medium">{editTarget.full_name ?? "—"}</div>
                <div className="text-muted-foreground">{editTarget.email ?? "—"}</div>
              </div>

              <div>
                <Label>Role</Label>
                <Select value={editRole} onValueChange={(v: PlatformRole) => setEditRole(v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="viewer">Viewer</SelectItem>
                    <SelectItem value="staff">Staff</SelectItem>
                    <SelectItem value="organizer_admin">Organizer Admin</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  {editRole === "viewer" && "Can view events, make predictions, join leaderboards."}
                  {editRole === "staff" && "Can update scores, manage fixtures, upload media."}
                  {editRole === "organizer_admin" && "Can manage all events and teams in their organization."}
                </p>
              </div>

              {needsOrg && (
                <div>
                  <Label>Organization</Label>
                  <Select value={editOrg} onValueChange={setEditOrg}>
                    <SelectTrigger><SelectValue placeholder="Select organization" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— No organization —</SelectItem>
                      {orgs.map((o) => (
                        <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {needsOrg && editOrg === "none" && (
                    <p className="text-xs text-destructive mt-1">
                      An organization must be selected for this role.
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditTarget(null)}>Cancel</Button>
            <Button
              onClick={saveRoleAssignment}
              disabled={busy || (needsOrg && editOrg === "none")}
              className="shadow-court"
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
