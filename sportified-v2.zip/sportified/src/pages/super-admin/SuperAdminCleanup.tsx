import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Archive, RotateCcw, Trash2, Building2, RefreshCw, AlertTriangle } from "lucide-react";

interface ArchivedEvent {
  id: string;
  name: string;
  sport: string;
  start_date: string;
  end_date: string;
  organization_id: string | null;
  orgName?: string;
}

interface UnusedOrg {
  id: string;
  name: string;
  eventCount: number;
  memberCount: number;
}

export default function SuperAdminCleanup() {
  const [archivedEvents, setArchivedEvents] = useState<ArchivedEvent[]>([]);
  const [unusedOrgs, setUnusedOrgs] = useState<UnusedOrg[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      // Load archived events
      const { data: archived } = await supabase
        .from("events")
        .select("id,name,sport,start_date,end_date,organization_id")
        .eq("status", "archived")
        .order("start_date", { ascending: false });

      // Load orgs for names
      const { data: orgs } = await supabase.from("organizations").select("id,name");
      const orgMap = new Map((orgs ?? []).map((o: any) => [o.id, o.name]));

      setArchivedEvents(
        (archived ?? []).map((e: any) => ({
          ...e,
          orgName: e.organization_id ? orgMap.get(e.organization_id) ?? "Unknown" : undefined,
        }))
      );

      // Find unused orgs (0 events, 0 members)
      const { data: events } = await supabase.from("events").select("organization_id");
      const { data: members } = await supabase.from("organization_members").select("organization_id");
      const eventTally: Record<string, number> = {};
      (events ?? []).forEach((e: any) => {
        if (e.organization_id) eventTally[e.organization_id] = (eventTally[e.organization_id] ?? 0) + 1;
      });
      const memberTally: Record<string, number> = {};
      (members ?? []).forEach((m: any) => {
        if (m.organization_id) memberTally[m.organization_id] = (memberTally[m.organization_id] ?? 0) + 1;
      });

      const unusedList: UnusedOrg[] = (orgs ?? [])
        .filter((o: any) => !eventTally[o.id] && !memberTally[o.id])
        .map((o: any) => ({
          id: o.id,
          name: o.name,
          eventCount: 0,
          memberCount: 0,
        }));
      setUnusedOrgs(unusedList);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const restoreEvent = async (ev: ArchivedEvent) => {
    const restoredStatus = new Date(ev.end_date) < new Date() ? "completed" : "upcoming";
    const { error } = await supabase.from("events").update({ status: restoredStatus }).eq("id", ev.id);
    if (error) toast.error(error.message);
    else { toast.success(`"${ev.name}" restored`); load(); }
  };

  const permanentDelete = async (id: string, name: string) => {
    setBusy(true);
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success(`"${name}" permanently deleted`); load(); }
    setBusy(false);
  };

  const purgeAllArchived = async () => {
    setBusy(true);
    const ids = archivedEvents.map((e) => e.id);
    if (!ids.length) { setBusy(false); return; }
    const { error } = await supabase.from("events").delete().in("id", ids);
    if (error) toast.error(error.message);
    else { toast.success(`Deleted ${ids.length} archived event(s)`); load(); }
    setBusy(false);
  };

  const deleteOrg = async (o: UnusedOrg) => {
    const { error } = await supabase.from("organizations").delete().eq("id", o.id);
    if (error) toast.error(error.message);
    else { toast.success(`"${o.name}" removed`); load(); }
  };

  const purgeAllUnusedOrgs = async () => {
    setBusy(true);
    const ids = unusedOrgs.map((o) => o.id);
    if (!ids.length) { setBusy(false); return; }
    const { error } = await supabase.from("organizations").delete().in("id", ids);
    if (error) toast.error(error.message);
    else { toast.success(`Removed ${ids.length} unused organization(s)`); load(); }
    setBusy(false);
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <header className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Pre-Launch Cleanup
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Remove test data, restore archived events, and clean up unused organizations before going live.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </header>

      {/* Archived Events */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h2 className="font-display font-semibold flex items-center gap-2">
              <Archive className="h-4 w-4 text-primary" />
              Archived Events
              <Badge variant="secondary">{archivedEvents.length}</Badge>
            </h2>
            <p className="text-xs text-muted-foreground">Restore or permanently delete archived events.</p>
          </div>
          {archivedEvents.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" disabled={busy}>
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete all archived
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete all {archivedEvents.length} archived events?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently remove all archived events and their associated matches, predictions, galleries, and leaderboard data. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={purgeAllArchived}
                  >
                    Delete all
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {loading ? (
          <Card className="p-8 text-center text-muted-foreground text-sm">Loading…</Card>
        ) : archivedEvents.length === 0 ? (
          <Card className="p-8 text-center text-muted-foreground text-sm">
            No archived events — you're clean!
          </Card>
        ) : (
          <div className="grid gap-2">
            {archivedEvents.map((ev) => (
              <Card key={ev.id} className="p-3 flex items-center justify-between gap-3 shadow-card border-destructive/20">
                <div className="min-w-0">
                  <div className="font-medium text-sm truncate">{ev.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {ev.sport}
                    {ev.orgName && ` · ${ev.orgName}`}
                    {" · "}
                    {new Date(ev.start_date).toLocaleDateString()} → {new Date(ev.end_date).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <Button variant="outline" size="sm" onClick={() => restoreEvent(ev)} className="gap-1">
                    <RotateCcw className="h-3.5 w-3.5" /> Restore
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" disabled={busy}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete "{ev.name}" permanently?</AlertDialogTitle>
                        <AlertDialogDescription>
                          All matches, teams, predictions, leaderboard data, and gallery items will be removed. This cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => permanentDelete(ev.id, ev.name)}
                        >
                          Delete permanently
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* Unused Organizations */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h2 className="font-display font-semibold flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" />
              Unused Organizations
              <Badge variant="secondary">{unusedOrgs.length}</Badge>
            </h2>
            <p className="text-xs text-muted-foreground">Organizations with no events and no members.</p>
          </div>
          {unusedOrgs.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" disabled={busy}>
                  <Trash2 className="h-4 w-4 mr-1" />
                  Remove all unused
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Remove all {unusedOrgs.length} unused organizations?</AlertDialogTitle>
                  <AlertDialogDescription>
                    These organizations have no events and no members. Removing them is safe. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={purgeAllUnusedOrgs}
                  >
                    Remove all
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {loading ? (
          <Card className="p-8 text-center text-muted-foreground text-sm">Loading…</Card>
        ) : unusedOrgs.length === 0 ? (
          <Card className="p-8 text-center text-muted-foreground text-sm">
            No unused organizations — all clean!
          </Card>
        ) : (
          <div className="grid gap-2">
            {unusedOrgs.map((o) => (
              <Card key={o.id} className="p-3 flex items-center justify-between gap-3 shadow-card">
                <div className="min-w-0">
                  <div className="font-medium text-sm">{o.name}</div>
                  <div className="text-xs text-muted-foreground">0 events · 0 members</div>
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove "{o.name}"?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This organization has no events or members. It will be permanently removed.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => deleteOrg(o)}
                      >
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </Card>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
